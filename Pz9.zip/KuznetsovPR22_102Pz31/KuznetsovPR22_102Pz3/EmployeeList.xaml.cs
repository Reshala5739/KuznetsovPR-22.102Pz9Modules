﻿using KuznetsovPR22_102Pz3.Model;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace KuznetsovPR22_102Pz3
{
    public partial class EmployeeList : Page
    {
        private Furniture_centerEntities db = new Furniture_centerEntities();
        private Auth currentUser;

        public EmployeeList(Auth user)
        {
            InitializeComponent();
            currentUser = user;
            LoadEmployees();
            if (currentUser.RoleID != 3)
            {
                btnAddEmployee.Visibility = Visibility.Collapsed;
            }

            UpdatePlaceholderVisibility();
        }
        public void LoadEmployees(string searchQuery = "")
        {
            var employees = db.Employees
                .Where(e => string.IsNullOrEmpty(searchQuery) ||
                            e.FirstName.Contains(searchQuery) ||
                            e.LastName.Contains(searchQuery) ||
                            e.MiddleName.Contains(searchQuery))
                .Select(e => new EmployeeClass
                {
                    EmployeeID = e.EmployeeID,
                    LastName = e.LastName,
                    FirstName = e.FirstName,
                    MiddleName = e.MiddleName,
                    PositionName = e.Positions.PositionName,
                    PhoneNumber = e.PhoneNumber,
                    Email = e.Email,
                    GenderID = e.GenderID == 1 ? "Мужской" : "Женский"
                })
                .ToList();

            lvEmployees.ItemsSource = employees;
        }
        private void Search_Click(object sender, RoutedEventArgs e)
        {
            LoadEmployees(tbSearch.Text.Trim());
        }
        private void AddEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (currentUser.RoleID == 3)
            {
                NavigationService.Navigate(new EmployeeFormAdd());
            }
        }
        public EmployeeList(Auth user, Furniture_centerEntities dbContext)
        {
            InitializeComponent();
            currentUser = user;
            db = dbContext;
            LoadEmployees();

            if (currentUser.RoleID != 3)
            {
                btnAddEmployee.Visibility = Visibility.Collapsed;
            }
            UpdatePlaceholderVisibility();
        }
        private void lvEmployees_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (lvEmployees.SelectedItem is EmployeeClass selectedEmployee)
            {
                var employee = db.Employees.FirstOrDefault(emp => emp.EmployeeID == selectedEmployee.EmployeeID);
                if (employee != null)
                {
                    NavigationService.Navigate(new EmployeeFormEdit(employee, db, this));
                }
            }
        }
        private void tbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdatePlaceholderVisibility();
        }
        private void tbSearch_GotFocus(object sender, RoutedEventArgs e)
        {
            UpdatePlaceholderVisibility();
        }
        private void tbSearch_LostFocus(object sender, RoutedEventArgs e)
        {
            UpdatePlaceholderVisibility();
        }
        private void UpdatePlaceholderVisibility()
        {
            tbPlaceholder.Visibility = string.IsNullOrWhiteSpace(tbSearch.Text) ? Visibility.Visible : Visibility.Hidden;
        }
    }
}