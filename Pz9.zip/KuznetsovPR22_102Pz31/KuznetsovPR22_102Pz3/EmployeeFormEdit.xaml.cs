﻿using KuznetsovPR22_102Pz3.Model;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace KuznetsovPR22_102Pz3
{
    public partial class EmployeeFormEdit : Page
    {
        private Furniture_centerEntities db;
        private Employees currentEmployee;
        private EmployeeList employeeListPage;

        public EmployeeFormEdit(Employees employee, Furniture_centerEntities dbContext, EmployeeList employeeList)
        {
            InitializeComponent();
            db = dbContext;
            currentEmployee = employee;
            employeeListPage = employeeList;

            LoadEmployeeData();
        }
        private void LoadEmployeeData()
        {
            tbSurname.Text = currentEmployee.LastName;
            tbName.Text = currentEmployee.FirstName;
            tbMiddleName.Text = currentEmployee.MiddleName;
            tbPhoneNumber.Text = currentEmployee.PhoneNumber;
            tbEmail.Text = currentEmployee.Email;
            cbPosition.SelectedValue = currentEmployee.PositionID;
            tbDateOfBirth.SelectedDate = currentEmployee.DateOfBirth;
            tbPassportSeries.Text = currentEmployee.PassportSeries;
            tbPassportNumber.Text = currentEmployee.PassportNumber;
            tbIssuedBy.Text = currentEmployee.IssuedBy;
            tbIssueDate.SelectedDate = currentEmployee.IssueDate;
            tbExperience.Text = currentEmployee.Experience_m_.ToString();
            tbSalary.Text = currentEmployee.Salary.ToString();
            tbHireDate.SelectedDate = currentEmployee.HireDate;
            rbMale.IsChecked = currentEmployee.GenderID == 1;
            rbFemale.IsChecked = currentEmployee.GenderID == 2;
            cbPosition.ItemsSource = db.Positions.ToList();
            cbPosition.DisplayMemberPath = "PositionName";
            cbPosition.SelectedValuePath = "PositionID";
        }
        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(tbSurname.Text) || string.IsNullOrWhiteSpace(tbName.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                currentEmployee.LastName = tbSurname.Text.Trim();
                currentEmployee.FirstName = tbName.Text.Trim();
                currentEmployee.MiddleName = tbMiddleName.Text.Trim();
                currentEmployee.PhoneNumber = tbPhoneNumber.Text.Trim();
                currentEmployee.Email = tbEmail.Text.Trim();
                currentEmployee.PositionID = (int)cbPosition.SelectedValue;
                currentEmployee.DateOfBirth = tbDateOfBirth.SelectedDate ?? DateTime.MinValue;
                currentEmployee.GenderID = rbMale.IsChecked == true ? 1 : 2;
                currentEmployee.PassportSeries = tbPassportSeries.Text.Trim();
                currentEmployee.PassportNumber = tbPassportNumber.Text.Trim();
                currentEmployee.IssuedBy = tbIssuedBy.Text.Trim();
                currentEmployee.IssueDate = tbIssueDate.SelectedDate ?? DateTime.MinValue;
                currentEmployee.Experience_m_ = int.TryParse(tbExperience.Text.Trim(), out int experience) ? experience : 0;
                currentEmployee.Salary = decimal.TryParse(tbSalary.Text.Trim(), out decimal salary) ? salary : 0m;
                currentEmployee.HireDate = tbHireDate.SelectedDate ?? DateTime.MinValue;
                db.SaveChanges();

                MessageBox.Show("Данные сотрудника успешно обновлены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                employeeListPage.LoadEmployees();
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}