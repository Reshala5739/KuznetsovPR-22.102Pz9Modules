﻿using KuznetsovPR22_102Pz3.Model;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace KuznetsovPR22_102Pz3
{
    public partial class EmployeeFormAdd : Page
    {
        private Furniture_centerEntities db = new Furniture_centerEntities();
        public EmployeeFormAdd()
        {
            InitializeComponent();

            // Загрузка списка должностей
            cbPosition.ItemsSource = db.Positions.ToList();
            cbPosition.DisplayMemberPath = "PositionName";
            cbPosition.SelectedValuePath = "PositionID";
        }
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(tbSurname.Text) || string.IsNullOrWhiteSpace(tbName.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                var newEmployee = new Employees
                {
                    LastName = tbSurname.Text.Trim(),
                    FirstName = tbName.Text.Trim(),
                    MiddleName = tbMiddleName.Text.Trim(),
                    PhoneNumber = tbPhoneNumber.Text.Trim(),
                    Email = tbEmail.Text.Trim(),
                    PositionID = (int)cbPosition.SelectedValue,
                    DateOfBirth = tbDateOfBirth.SelectedDate.Value,
                    GenderID = rbMale.IsChecked == true ? 1 : 2,
                    PassportSeries = tbPassportSeries.Text.Trim(),
                    PassportNumber = tbPassportNumber.Text.Trim(),
                    IssuedBy = tbIssuedBy.Text.Trim(),
                    IssueDate = tbIssueDate.SelectedDate.Value,
                    Experience_m_ = int.TryParse(tbExperience.Text.Trim(), out int experience) ? experience : 0,
                    Salary = decimal.TryParse(tbSalary.Text.Trim(), out decimal salary) ? salary : 0m,
                    HireDate = tbHireDate.SelectedDate.Value
                };
                db.Employees.Add(newEmployee);
                db.SaveChanges();
                MessageBox.Show("Данные успешно добавлены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
